<div class="page-header">
  <h1><?php echo title(); ?></h1>
</div>

<div class="entry-content">
  <p><?php _e('Sorry, but the page you were trying to view does not exist.', 'r_bot'); ?></p>
  <?php get_search_form(); ?>
</div>
