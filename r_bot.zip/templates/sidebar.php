<div class="sticky">
  <?php dynamic_sidebar('sidebar-primary'); ?>
</div>
